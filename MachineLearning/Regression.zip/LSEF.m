function [err]=LSEF
  x=[1 2 3 4];
  y=[1 4 9 16];
  A=[1 1;2 1;3 1;4 1];
  b=[1;4;9;16];
  scatter(x,y);
  xhat=(inv(transpose(A)*A)*transpose(A))*b;
  m=xhat(1);c=xhat(2);
  x1=0:0.1:5;
  y1=m*x1+c*ones(size(x1));
  for i=1:4
  y2(i)=m*i+c;
endfor
round(y2)
  hold on;
  plot(x1,y1);
  err=norm(y-y2);
endfunction
