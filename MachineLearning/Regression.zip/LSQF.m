function LSQF
  x=[1 2 3 4];
  y=[1 4 9 16];
  A=[1 1 1;4 2 1;9 3 1;16 4 1];
  b=[1;4;9;16];
  scatter(x,y);
  xhat=(inv(transpose(A)*A)*transpose(A))*b;
  a=xhat(1);b=xhat(2); c=xhat(3);
  x1=0:0.1:5;
  y1=a*x1.^2+b*x1+c*ones(size(x1));
  hold on;
  plot(x1,y1);
endfunction