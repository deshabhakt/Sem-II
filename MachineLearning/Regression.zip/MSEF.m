function [m,c]=MSEF
  x=[1 2 3 4];
  y=[1 4 9 16];
  scatter(x,y);
  A=[sum(x.^2) sum(x);sum(x) 4];
  b=[sum(x.*y); sum(y)];
  xhat=((inv(transpose(A)*A))*transpose(A))*b;
  m=xhat(1);c=xhat(2);
  x1=0:0.1:5;
  y1=m*x1+c*ones(size(x1));
  hold 
  plot(x1,y1);
endfunction
